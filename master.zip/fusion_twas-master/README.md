# Functional Summary-based Imputation

*FUSION is a suite of tools for performing a transcriptome-wide (or any other ome-wide) association study by predicting functional/molecular phenotypes into GWAS using only summary statistics.*

Please see [http://gusevlab.org/projects/fusion/](http://gusevlab.org/projects/fusion/) for documentation.
